The yWriter importer for Aeon Timeline 2 can be found here:
https://peter88213.github.io/aeon2yw/